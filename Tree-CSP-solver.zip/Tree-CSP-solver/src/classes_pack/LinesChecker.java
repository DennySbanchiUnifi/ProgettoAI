package classes_pack;

public class LinesChecker {
	
	private Boolean isDot1, isDot2, isDot3, isDot4; // serve a capire se l'eventale punto di intersezione � uno dei nodi passati alla funzione 
	private Boolean controlOnDots;
	double precision = 0.00001;
	double x, y;


	public Boolean calculateIntersection(double x1,double y1, double x2,double y2, double x3,double y3, double x4,double y4){
		double a1, a2, b1, b2, coeffx1, coeffx2, const_term1, const_term2; 
		double x_l, x_r; // mi servono per verificare che il punto di inters. appartegna ai segmenti e non semplicemente alle rette 
		Boolean inSegm1, inSegm2; // appartenenza ad entrambi i segmenti delle rette
		Boolean result=false;
		
		a1 = (y2-y1);
		b1 = (x2-x1);

		a2 = (y4-y3);
		b2 = (x4-x3);
		
		controlOnDots = true;
		
		// Casi in cui una delle due rette sia verticale
		if (b1==0) //prima retta verticale
			calculateSpecialCasesVert(x1, y1, x2, y2, x3, y3, x4, y4);
		else if (b2==0) //seconda retta verticale (scambio ordine paraetri funzione)
			calculateSpecialCasesVert(x3, y3, x4, y4, x1, y1, x2, y2);	
		// Casi in cui una delle due rette sia orizzontale
		else if (a1==0)
			calculateSpecialCasesHor(x1, y1, x2, y2, x3, y3, x4, y4);
		else if (b2==0) //seconda retta verticale (scambio ordine parametri funzione)
			calculateSpecialCasesHor(x3, y3, x4, y4, x1, y1, x2, y2);
		else{
			coeffx1 = (a1/b1);
			const_term1 = - coeffx1*x2 + y2;
			coeffx2 = (a2/b2);
			const_term2 = - coeffx2*x4 + y4;
			x = (const_term2-const_term1)/(coeffx1-coeffx2);  // i punti di partenza, allora i due segmenti sono incidenti
			y = (coeffx1*x+const_term1);
			if (coeffx1 == coeffx2) // stesso coeff. angolare rette parallele, mai incidenti
				controlOnDots = false;
		}
		
		if (!controlOnDots)
			result = false;
		else if (controlOnDots){ 	// calcolo x ed y del punto di incontro, e controllo se appartiene ai segmenti descritti dai punti passati alla funzione
			isDot1 = (Math.abs(x - x1)<precision) && (Math.abs(y - y1)<precision);
			isDot2 = (Math.abs(x - x2)<precision) && (Math.abs(y - y2)<precision);
			isDot3 = (Math.abs(x - x3)<precision) && (Math.abs(y - y3)<precision);
			isDot4 = (Math.abs(x - x4)<precision) && (Math.abs(y - y4)<precision);
			x_l = Math.min(x1, x2);
			x_r = Math.max(x1, x2);
			inSegm1 = (x >= x_l ) && ( x <= x_r );
			x_l = Math.min(x3, x4);
			x_r = Math.max(x3, x4);
			inSegm2 = (x >= x_l ) && ( x <= x_r );
			if ( inSegm1 && inSegm2 && !isDot1 && !isDot2 && !isDot3 && !isDot4) // se il punto di inters. rientra nel mio unit quare e non � uno dei nodi passati alla funzione
				result = true;
		}	
		return result;
	}
	
	private void calculateSpecialCasesVert(double x1,double y1, double x2,double y2, double x3,double y3, double x4,double y4){
		double a2, b2, coeffx2, const_term2; 

		a2 = (y4-y3);
		b2 = (x4-x3);
		
		
		if (b2==0){ // seconda retta verticale
			controlOnDots = false;
		}
		else if (a2==0){ // seconda retta orizzontale
			x = x1;  // i punti di partenza, allora i due segmenti sono incidenti
			y = y3;
		}
		else{
			coeffx2 = (a2/b2);
			const_term2 = - coeffx2*x4 + y4;
			x = x1;
			y = (coeffx2*x+const_term2);
		}
	}
	
	private void calculateSpecialCasesHor(double x1,double y1, double x2,double y2, double x3,double y3, double x4,double y4){
		double a2, b2, coeffx2, const_term2; 

		a2 = (y4-y3);
		b2 = (x4-x3);
		
		
		if (a2==0){ // seconda retta verticale
			controlOnDots = false;
		}
		else if (b2==0){ // seconda retta verticale
			x = x3;  // i punti di partenza, allora i due segmenti sono incidenti
			y = y1;
		}
		else{ // seconda retta n� orizz. n� vert.
			coeffx2 = (a2/b2);
			const_term2 = - coeffx2*x4 + y4;
			y = y1;
			x = (y-const_term2)/coeffx2;
		}
	}

}
