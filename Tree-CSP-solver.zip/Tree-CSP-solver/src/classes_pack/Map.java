package classes_pack;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;

public class Map {

	private int n;
	private int number_of_colours;
	private List<Node> nodes;
	private Double[][] distances;
	private List<Connection> connections;
	private Hashtable<Double, Double> coord;
	private Integer[][] already_tested;
	private List<Node> node_to_test;
	private LinesChecker lines_checker;
	
	public Map(int n, int number_of_colours){
		this.n = n;
		this.number_of_colours = number_of_colours;
		nodes = new ArrayList<Node>();
		distances = new Double[n][n];
		connections = new ArrayList<Connection>();
		coord = new Hashtable<Double, Double>();
		already_tested = new Integer[n][n];
		node_to_test =  new ArrayList<Node>();
		lines_checker = new LinesChecker();
		initMatrix(already_tested);
		generateNodes();
		connectNodes();
	}
	
	public void initMatrix(Integer[][] matrix){
		int i,j;
		for(i=0;i<matrix[0].length;i++)
			for(j=0;j<matrix[0].length;j++){
				if (i==j)
					matrix[i][j] = 1;
				else
					matrix[i][j]= 0;
			}		
	}
	
	private void generateNodes(){
		int j,i=0;
		double x, y;
		double distance;
		Node app;
		Random random = new Random();
		while(i<n){
			x = random.nextDouble();
			y = random.nextDouble();
			if ((!coord.contains(x)) || ( coord.contains(x) && (!(coord.get(x)==y))) ){
				app = new Node(x,y,i, number_of_colours);
				nodes.add(app);
				node_to_test.add(app);
				coord.put(x, y);
				for(j=0; j<i; j++){
					distance = calculateDistance(j,i);
					distances[j][i] = distance;
					distances[i][j] = distance;
				}
				distances[i][i] = 0.0;
				i++;
			}
		}
	}
	
	private double calculateDistance(int j, int i){
		double dist;
		double x, y;
		x = Math.abs(nodes.get(j).getX()-nodes.get(i).getX());
		y = Math.abs(nodes.get(j).getY()-nodes.get(i).getY());
		dist = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
		return dist;
	}
	
	private void connectNodes(){
		Random random = new Random();
		int X, Y;
		Boolean ok = false;
		while(!ok){
			X = random.nextInt(node_to_test.size());
			if (checkTestedNode(X))
				node_to_test.remove(X);
			else{
				Y = getNearest(X);
				if ((Y >= 0) && (!nodes.get(X).containNeighbour(nodes.get(Y)))){
					if (checkLine(X,Y)){
						connections.add(new Connection(nodes.get(X), nodes.get(Y)));
						nodes.get(X).addToList(nodes.get(Y)); // li aggiungo ai vicini
						nodes.get(Y).addToList(nodes.get(X));
					}
					already_tested[X][Y] = 1; // sia che siano collegabili o meno il test su X e Y va registrato
					already_tested[Y][X] = 1;
				}
			}
			ok = node_to_test.isEmpty();
		}
	}
	
	private int getNearest(int X){
		double min=2; // Non basta min=1.0 in quanto per errori dovuti agli arrotondamenti alcune distanze sono > 1 anche se in realt� non lo sarebbero
		int index=-1, i=0;
		for(i=0;i<n;i++){
			if ((X!=i) && (distances[X][i]<min) && (already_tested[X][i] != 1)){
				min = distances[X][i];
				index = i;
			}
		}
		return index;		
	}
	
	private Boolean checkLine(int X, int Y){ // Testa che la linea che si vuole disegnare non si sovrapponga alle altre gi� disegnate
		int i,P1, P2;
		Boolean result = true;
		double x1,y1,x2,y2;
		
		x1 = nodes.get(X).getX();
		y1 = nodes.get(X).getY();
		x2 = nodes.get(Y).getX();
		y2 = nodes.get(Y).getY();
		
		for (i=0;i<connections.size();i++){
			P1 = connections.get(i).getP1().getId();
			P2 = connections.get(i).getP2().getId();
			if  (lines_checker.calculateIntersection(x1, y1, x2, y2, nodes.get(P1).getX(), nodes.get(P1).getY(), nodes.get(P2).getX(), nodes.get(P2).getY()))
				result = false;
		}
		return result;
	}
	
	
	private Boolean checkTestedNode(int X){
		Boolean result = true;
		int i;
		for(i=0;i<already_tested[0].length;i++){
			if (already_tested[X][i] == 0)
				result = false;
		}
		return result;
	}
	
	public void listNodes(){
		int i;
		for (i=0;i<n;i++){
			System.out.println("P"+i+" = ("+nodes.get(i).getX()+" , "+nodes.get(i).getY()+")");
		}
	}
	
	public void listDistances(){
		int i,j;
		NumberFormat nf = new DecimalFormat("0.00");
		for (i=0;i<n;i++){
			for(j=0;j<n;j++)
				System.out.format(nf.format(distances[i][j])+" ");
			System.out.println();
		}
	}
	
	public void listConnections(){
		int i;
		for (i=0;i<connections.size();i++)
			System.out.println(connections.get(i).getConnectionValues());
	}

	public List<Node> getNodes() {
		return nodes;
	}

	public List<Connection> getConnections() {
		return connections;
	}
	
	

}
