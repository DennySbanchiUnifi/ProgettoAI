package classes_pack;

import java.util.ArrayList;
import java.util.List;

public class SpanningTreeGenerator {
	
	private List<Connection> connections;
	private List<Node> frontier;
	private List<Connection> spanning_tree;
	
	
	public SpanningTreeGenerator(List<Connection> connections){
		this.connections = connections;
		frontier = new ArrayList<Node>();
		spanning_tree = new ArrayList<Connection>();
		generateSpanningTree();
		updateNeighbors();
	}
	
	private void generateSpanningTree(){
		int i=0, num_neighbours;
		Boolean stop = false;
		Node nodex, node_neighbour;
		nodex = connections.get(0).getP1();
		do{
			num_neighbours = nodex.getNeighbors().size();
			for (i=0;i<num_neighbours;i++){
				node_neighbour = nodex.getNeighbors().remove(0);
				node_neighbour.getNeighbors().remove(nodex);
				if (! frontier.contains(node_neighbour) ){
					frontier.add(node_neighbour);
					spanning_tree.add(new Connection(nodex, node_neighbour));
				}
			}
			if (frontier.size()>=1)
				nodex = frontier.remove(0);
			else
				stop = true;
		}while(!stop);		
	}
	
/*	private void printSpanningTree(){
		System.out.println("\n SPANNING TREE \n");
		for (Connection c : spanning_tree)
			System.out.println("Nodo "+c.getP1().getId()+" collegato con "+c.getP2().getId());
	} */
	
	private void updateNeighbors(){
		Node n1, n2;
		for (Connection c : spanning_tree){
			n1 = c.getP1();
			n2 = c.getP2();
			n1.addToList(n2);
			n2.addToList(n1);
		}
	}

	public List<Connection> getSpanning_tree() {
		return spanning_tree;
	}
	
	
	
}
