package classes_pack;

import java.util.ArrayList;
import java.util.List;

public class Node {
	
	private double x;
	private double y;
	private int id;
	private int index_sorted_parent;
	private List<Node> neighbors;
	private List<Colour> colours;
	private String[] colours_of_domain = {"red","yellow","green","blue"};
	
	public Node(double x, double y, int id, int number_of_colours){
		this.x = x;
		this.y = y;
		this.id = id;
		this.colours =  new ArrayList<Colour>();
		initColours(number_of_colours);
		neighbors = new ArrayList<Node>();
	}
	
	private void initColours(int number){
		int i;
		for(i=0;i<number;i++)
			colours.add(new Colour(colours_of_domain[i]));
	};

	public int getId() {
		return id;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
	public void addToList(Node e){
		neighbors.add(e);
	}
	
	public Boolean containNeighbour(Node e){
		return neighbors.contains(e);
	}
	
	public void listNeighbors(){
		int i;
		for (i=0;i<neighbors.size();i++)
			System.out.print(neighbors.get(i).getId()+" ");
	}

	public List<Node> getNeighbors() {
		return neighbors;
	}

	public int getIndex_sorted_parent() {
		return index_sorted_parent;
	}

	public void setIndex_sorted_parent(int index_sorted_parent) {
		this.index_sorted_parent = index_sorted_parent;
	}

	public List<Colour> getColours() {
		return colours;
	}
	
	public void printColours(){
		for(Colour c : colours)
			System.out.print(c.getName()+" ");
	}
	
	
	

}
