package classes_pack;

public class Connection {
	
	private Node P1;
	private Node P2;
	
	public Connection(Node P1, Node P2){
		this.P1 = P1;
		this.P2 = P2;
	}

	public String getConnectionValues(){
		return "Nodo "+P1.getId() + " connesso con nodo "+P2.getId();
	}

	public Node getP1() {
		return P1;
	}

	public Node getP2() {
		return P2;
	}
	
	
}
