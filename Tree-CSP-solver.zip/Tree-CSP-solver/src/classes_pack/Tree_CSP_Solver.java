package classes_pack;

import java.util.ArrayList;
import java.util.List;

public class Tree_CSP_Solver {
	
	private int n;
	private List<Colour> assignment;
	private List<Node> nodes;
	private List<Connection> connections;
	
	public Tree_CSP_Solver(List<Node> nodes, List<Connection> connections){
		this.nodes = nodes;
		this.connections = connections;
		n = nodes.size();
		assignment = new ArrayList<Colour>();
	}
	
	public Boolean solveCSP(){
		int i;
		Node nodex;
		Boolean arc_consistent = true, result=true;
		nodes = topologicalSort();
		for (i=n-1;i>0;i--){
			nodex = nodes.get(i);
			arc_consistent = makeArcConsistent(nodes.get(nodex.getIndex_sorted_parent()), nodex);
			if (!arc_consistent){
				i = 0;
			}
		}
		if (!arc_consistent)
			result = false;
		else{
			for (i=0;i<n;i++){
				if (nodes.get(i).getColours().size() == 0){
					result = false;
					i = n;
				}
				assignment.add(nodes.get(i).getColours().get(0));
			}
			
		}
		return result;
	}
	
	private List<Node> topologicalSort(){
		List <Node> nodes = new ArrayList<Node>();
		Node nodex;
		for (Connection c : connections){
			nodex = c.getP1();
			if (! nodes.contains(nodex))
				nodes.add(nodex);
			for (Node n : c.getP1().getNeighbors()){
				if (! nodes.contains(n)){
					n.setIndex_sorted_parent(nodes.indexOf(nodex));
					nodes.add(n);
				}
			}
		}
		return nodes;		
	}
	
	private Boolean makeArcConsistent(Node parent, Node child){
		Boolean possible=true;
		int i, size, saved, max=0;
		String colour_name = "";
		size = child.getColours().size();
		if ((child.getColours().size() == 0) || (parent.getColours().size() == 0))
			possible = false;
		else{
			for (i=0;i<size;i++){ // Scorro i valori di child per trovare quello che me ne preserva di più nel parent
				saved = makeConsistentColours(parent, child, child.getColours().get(i).getName());
				if (saved >= max){
					colour_name = child.getColours().get(i).getName();
					max=saved;
				}
			}
			i = 0;
			while (child.getColours().size()>1){
				if (!child.getColours().get(i).getName().equals(colour_name))
					child.getColours().remove(i);
				else
					i=i+1;
			}
			size = parent.getColours().size();
			for (i=0;i<size;i++){
				if (parent.getColours().get(i).getName().equals(colour_name)){
					parent.getColours().remove(i);
					i = size;
				}
			}	
		}
		if (parent.getColours().size() == 0)
			possible = false;
		return possible;
	}
	
	public Integer makeConsistentColours(Node parent, Node child, String colour_name){
		int i=0, saved, size;
		Boolean found=false;
		
		saved = parent.getColours().size();
		size = parent.getColours().size();
		for (i=0;i<size;i++){
			if (parent.getColours().get(i).getName().equals(colour_name))
				found = true;			
		}
		if (found)
			saved = parent.getColours().size()-1;
		return saved;
	}
	
	public void printAssignment(){
		int i;
		for(i=0;i<assignment.size();i++)
			System.out.println("Nodo "+nodes.get(i).getId()+" "+assignment.get(i).getName()+" ");
	}
	
}
