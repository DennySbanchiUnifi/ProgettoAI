package classes_pack;

public class Colour {
	
	private String name;
	
	public Colour(String name){
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

}
