package exec_pack;

import classes_pack.Map;
import classes_pack.SpanningTreeGenerator;
import classes_pack.Tree_CSP_Solver;

import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		int n=0, number_of_colours = 4;
		Boolean ok= false, solution;
		long time_start = 0, time_end = 0, total_start, total_end;
		Scanner input = new Scanner(System.in);
		Map map;
		SpanningTreeGenerator sp_tree;
		Tree_CSP_Solver solver;

		while (!ok) {
		    System.out.println("Inserisci un numero di nodi positivo:" );
		    if (!input.hasNextInt()) {
		     input.next();
		    }
		    else {
		      n = input.nextInt();
		      if (n > 0)
			    ok = true;
		    }
		}
		input.close();
		total_start = System.currentTimeMillis();
		if (n == 1)
			solution = true;
		else{
			map = new Map(n, number_of_colours);
			sp_tree = new SpanningTreeGenerator(map.getConnections());
			solver = new Tree_CSP_Solver(map.getNodes(), sp_tree.getSpanning_tree());
			time_start = System.currentTimeMillis();
			solution = solver.solveCSP();	
			time_end = System.currentTimeMillis();
		}
		total_end = System.currentTimeMillis();
		if (solution)
			System.out.println("E' stato possibile trovare un valido assegnamento di colori per ogni nodo.");
		else
			System.out.println("Nessun assegnamento di colori possibile.");
		System.out.println("Tempo impiegato esecuzione dell'algoritmo Tree-CSP-solver: "+(time_end-time_start)+" millisecondi.");
		System.out.println("Tempo impiegato esecuzione totale: "+(total_end-total_start)+" millisecondi.");
	}

}
